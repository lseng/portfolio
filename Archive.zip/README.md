I'm creating this as my own personal website. I've used two templates to do so.
